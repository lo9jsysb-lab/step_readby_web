import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
// 引入 CSS2DRenderer 用于显示测量文字标签
import { CSS2DRenderer, CSS2DObject } from 'three/examples/jsm/renderers/CSS2DRenderer.js';

import initOpenCascade from 'opencascade.js/dist/opencascade.full.js';

let oc = null;
let scene, camera, renderer, labelRenderer, controls;
let raycaster, mouse;
let measureMode = false;
let measurePoints = [];
let measureLine = null;
let measureLabel = null;

// 初始化
function init() {
  const container = document.getElementById('canvas-container');

  // 1. 场景
  scene = new THREE.Scene();
  scene.background = new THREE.Color(0xf0f0f0);

  // 2. 相机
  camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(50, 50, 50);

  // 3. 渲染器 (WebGL)
  renderer = new THREE.WebGLRenderer({ antialias: true }); // 开启抗锯齿
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(window.devicePixelRatio); // 高清屏适配
  container.appendChild(renderer.domElement);

  // 4. 标签渲染器 (用于显示测量数值)
  labelRenderer = new CSS2DRenderer();
  labelRenderer.setSize(window.innerWidth, window.innerHeight);
  labelRenderer.domElement.style.position = 'absolute';
  labelRenderer.domElement.style.top = '0px';
  labelRenderer.domElement.style.pointerEvents = 'none'; // 让鼠标事件穿透到 WebGL
  container.appendChild(labelRenderer.domElement);

  // 5. 控制器
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;

  // 6. 灯光 (增强立体感)
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
  scene.add(ambientLight);

  const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.8);
  dirLight1.position.set(10, 20, 10);
  scene.add(dirLight1);
  
  const dirLight2 = new THREE.DirectionalLight(0xffffff, 0.3);
  dirLight2.position.set(-10, -10, -10); // 补光
  scene.add(dirLight2);

  // 7. 交互准备
  raycaster = new THREE.Raycaster();
  mouse = new THREE.Vector2();

  window.addEventListener('resize', onWindowResize);
  window.addEventListener('click', onMouseClick); // 监听点击用于测量
  
  // UI 事件
  document.getElementById('btnMeasure').addEventListener('click', toggleMeasureMode);

  animate();
}

function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
  labelRenderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
  requestAnimationFrame(animate);
  controls.update();
  renderer.render(scene, camera);
  labelRenderer.render(scene, camera);
}

// --- 测量功能逻辑 ---
function toggleMeasureMode() {
  measureMode = !measureMode;
  const btn = document.getElementById('btnMeasure');
  const status = document.getElementById('status');
  
  if (measureMode) {
    btn.innerText = "退出测量";
    btn.style.backgroundColor = "#ff4444";
    status.innerText = "测量模式：请点击模型上的两个点";
    controls.enabled = false; // 测量时禁用旋转，防止误触
    clearMeasure();
  } else {
    btn.innerText = "开始测量";
    btn.style.backgroundColor = "#4CAF50";
    status.innerText = "查看模式";
    controls.enabled = true;
    clearMeasure();
  }
}

function clearMeasure() {
  measurePoints = [];
  if (measureLine) {
    scene.remove(measureLine);
    measureLine.geometry.dispose();
    measureLine.material.dispose();
    measureLine = null;
  }
  if (measureLabel) {
    scene.remove(measureLabel);
    measureLabel = null;
  }
}

function onMouseClick(event) {
  if (!measureMode || !oc) return;

  // 计算鼠标位置
  mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
  mouse.y = -(event.clientY / window.innerHeight) * 2 + 1;

  raycaster.setFromCamera(mouse, camera);

  // 获取模型对象
  const model = scene.getObjectByName("stepModel");
  if (!model) return;

  const intersects = raycaster.intersectObject(model, true);

  if (intersects.length > 0) {
    const point = intersects[0].point;
    
    // 添加一个小球标记点
    const sphereGeo = new THREE.SphereGeometry(0.5, 16, 16);
    const sphereMat = new THREE.MeshBasicMaterial({ color: 0xff0000 });
    const sphere = new THREE.Mesh(sphereGeo, sphereMat);
    sphere.position.copy(point);
    scene.add(sphere);
    measurePoints.push({ point: point, marker: sphere });

    if (measurePoints.length === 2) {
      drawMeasureLine();
      // 测完后自动退出或等待下一次
      // toggleMeasureMode(); // 可选：测完一次自动退出
    } else if (measurePoints.length > 2) {
      // 重置
      clearMeasure();
      // 重新添加当前点
      const sphereGeo = new THREE.SphereGeometry(0.5, 16, 16);
      const sphereMat = new THREE.MeshBasicMaterial({ color: 0xff0000 });
      const sphere = new THREE.Mesh(sphereGeo, sphereMat);
      sphere.position.copy(point);
      scene.add(sphere);
      measurePoints.push({ point: point, marker: sphere });
    }
  }
}

function drawMeasureLine() {
  if (measurePoints.length < 2) return;

  const p1 = measurePoints[0].point;
  const p2 = measurePoints[1].point;

  // 1. 画线
  const points = [p1, p2];
  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const material = new THREE.LineBasicMaterial({ color: 0x0000ff, linewidth: 2 });
  measureLine = new THREE.Line(geometry, material);
  scene.add(measureLine);

  // 2. 计算距离
  const distance = p1.distanceTo(p2);
  
  // 3. 创建文字标签
  const div = document.createElement('div');
  div.className = 'measure-label';
  div.textContent = distance.toFixed(2) + ' mm'; // 假设单位是 mm
  div.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
  div.style.color = 'white';
  div.style.padding = '4px 8px';
  div.style.borderRadius = '4px';
  div.style.fontSize = '14px';
  div.style.fontFamily = 'monospace';

  measureLabel = new CSS2DObject(div);
  // 标签放在线段中间
  measureLabel.position.copy(p1).lerp(p2, 0.5);
  // 稍微抬高一点防止被遮挡
  measureLabel.position.y += 1; 
  scene.add(measureLabel);

  document.getElementById('status').innerText = `距离: ${distance.toFixed(2)} mm`;
}

// --- OpenCascade 加载与解析 ---
async function initOpenCascadeEngine() {
  const statusDiv = document.getElementById('status');
  try {
    const wasmUrl = '/opencascade.full.wasm'; 
    oc = await initOpenCascade({
      locateFile: (fileName) => fileName.endsWith('.wasm') ? wasmUrl : fileName
    });
    console.log("OpenCascade Ready");
    statusDiv.innerText = "引擎就绪";
    statusDiv.style.color = "green";
    document.getElementById('fileInput').disabled = false;
  } catch (error) {
    console.error(error);
    statusDiv.innerText = "引擎加载失败";
  }
}

document.addEventListener('DOMContentLoaded', () => {
  const fileInput = document.getElementById('fileInput');
  if (fileInput) {
    fileInput.addEventListener('change', async (event) => {
      const file = event.target.files[0];
      if (!file || !oc) return;

      const statusDiv = document.getElementById('status');
      statusDiv.innerText = `正在读取: ${file.name} ...`;

      const reader = new FileReader();
      reader.onload = async function(e) {
        const uint8Array = new Uint8Array(e.target.result);
        statusDiv.innerText = "正在高精度解析...";
        
        try {
          const filename = "model.step";
          oc.FS.writeFile(filename, uint8Array);
          const reader = new oc.STEPControl_Reader_1();
          const status = reader.ReadFile(filename);

          if (status === oc.IFSelect_ReturnStatus.IFSelect_RetDone) {
            reader.TransferRoots(new oc.Message_ProgressRange_1());
            const shape = reader.OneShape();
            
            // 清除旧模型和测量
            const oldMesh = scene.getObjectByName("stepModel");
            if (oldMesh) scene.remove(oldMesh);
            clearMeasure();

            const mesh = shapeToMesh(shape, oc);
            if (mesh) {
              mesh.name = "stepModel";
              scene.add(mesh);
              
              // 自动视角
              const box = new THREE.Box3().setFromObject(mesh);
              const center = box.getCenter(new THREE.Vector3());
              const size = box.getSize(new THREE.Vector3());
              const maxDim = Math.max(size.x, size.y, size.z);
              controls.target.copy(center);
              camera.position.copy(center).add(new THREE.Vector3(maxDim, maxDim, maxDim));
              
              statusDiv.innerText = `加载成功: ${file.name}`;
            }
          }
          oc.FS.unlink(filename);
        } catch (err) {
          console.error(err);
          statusDiv.innerText = "解析出错";
        }
      };
      reader.readAsArrayBuffer(file);
    });
  }
});

// --- 核心：高精度网格化 ---
function shapeToMesh(shape, oc) {
  const mesh = new THREE.Group();
  
  // ✅ 提升清晰度关键：减小 deflection
  // 0.1 是粗糙，0.01 是高清，0.001 是超清(慢)
  // 对于 < 20MB 文件，0.01 通常是可以接受的平衡点
  const linearDeflection = 0.01; 
  const angularDeflection = 0.1; // 角度精度也提高
  
  const mesher = new oc.BRepMesh_IncrementalMesh_2(shape, linearDeflection, false, angularDeflection, false);
  mesher.Perform(new oc.Message_ProgressRange_1());
  
  if (mesher.IsDone()) {
    const loc = new oc.TopLoc_Location_1();
    const faces = new oc.TopExp_Explorer_2(shape, oc.TopAbs_ShapeEnum.TopAbs_FACE, oc.TopAbs_ShapeEnum.TopAbs_SHAPE);
    
    while (faces.More()) {
      const face = oc.TopoDS.Face_1(faces.Current());
      const triangulation = oc.BRep_Tool.Triangulation(face, loc, 0);
      
      if (triangulation !== null && !triangulation.IsNull()) {
        const trsf = loc.Transformation();
        const nbNodes = triangulation.get().NbNodes();
        const nbTriangles = triangulation.get().NbTriangles();
        
        const vertices = new Float32Array(nbNodes * 3);
        const indices = new Uint32Array(nbTriangles * 3);
        
        for (let i = 1; i <= nbNodes; i++) {
          const node = triangulation.get().Node(i);
          const p = new oc.gp_Pnt_3(node.X(), node.Y(), node.Z());
          p.Transform(trsf);
          vertices[(i - 1) * 3] = p.X();
          vertices[(i - 1) * 3 + 1] = p.Y();
          vertices[(i - 1) * 3 + 2] = p.Z();
          p.delete();
        }
        
        let isForward = true;
        try {
           if (typeof face.Orientation === 'function') {
             isForward = (face.Orientation() === oc.TopAbs_Orientation.TopAbs_FORWARD);
           }
        } catch(e) {}

        for (let i = 1; i <= nbTriangles; i++) {
          const tri = triangulation.get().Triangle(i);
          if (isForward) {
            indices[(i - 1) * 3] = tri.Value(1) - 1;
            indices[(i - 1) * 3 + 1] = tri.Value(2) - 1;
            indices[(i - 1) * 3 + 2] = tri.Value(3) - 1;
          } else {
            indices[(i - 1) * 3] = tri.Value(1) - 1;
            indices[(i - 1) * 3 + 1] = tri.Value(3) - 1;
            indices[(i - 1) * 3 + 2] = tri.Value(2) - 1;
          }
        }
        
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
        geometry.setIndex(new THREE.BufferAttribute(indices, 1));
        geometry.computeVertexNormals(); // 平滑着色关键
        
        // 材质优化：使用 Physical 材质更接近真实工业零件
        const material = new THREE.MeshPhysicalMaterial({ 
          color: 0xcccccc, 
          side: THREE.DoubleSide,
          roughness: 0.4,
          metalness: 0.1,
          clearcoat: 0.1,
          flatShading: false // 确保平滑着色
        });
        
        mesh.add(new THREE.Mesh(geometry, material));
      }
      faces.Next();
    }
    faces.delete();
    loc.delete();
  }
  mesher.delete();
  return mesh.children.length > 0 ? mesh : null;
}

init();
initOpenCascadeEngine();